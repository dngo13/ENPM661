#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-

import numpy as np
# import cv2
import math
from Queue import PriorityQueue
import time
import matplotlib.pyplot as plt
import rospy
import tf
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Twist, Point

# import bot_controller

# Initialize your ROS node
rospy.init_node("astar")
# Set up a publisher to the /cmd_vel topic
pub = rospy.Publisher("/cmd_vel", Twist, queue_size=5)
start_time = time.time()
# Define workspace
ws_width = 1000
ws_height = 1000
# Clearance
# global clr
# Euclidean distance
euc = 0.5
# Theta threshold
theta_thresh = 30
img = np.zeros([ws_height, ws_width, 3], dtype=np.uint8)
radius = 33  # cm
wheel_d = 89  # cm

# Declare a message of type Twist
velocity_msg = Twist()
# set up a tf listener to retrieve transform between the robot and the world
tf_listener = tf.TransformListener()
parent_frame = 'odom'
# child frame for the listener
child_frame = 'base_footprint'
# publish the velocity at 4 Hz (4 times per second)
rate = rospy.Rate(100)
global RPM_L, RPM_R


# i being parent coordinate and UL/UR children
# def plot_curve(Xi, Yi, Thetai, UL, UR):
#     t = 0
#     r = 3.8
#     L = 35.4
#     dt = 0.1
#     Xn = Xi
#     Yn = Yi
#     Thetan = np.pi * Thetai / 180
#     # Xi, Yi,Thetai: Input point's coordinates
#     # Xs, Ys: Start point coordinates for plot function
#     # Xn, Yn, Thetan: End point coordintes
#     D = 0
#     while t < 1:
#         t = t + dt
#         Xs = Xn
#         Ys = Yn
#         Xn += 0.5*r * (UL + UR) * math.cos(Thetan) * dt
#         Yn += 0.5*r * (UL + UR) * math.sin(Thetan) * dt
#         Thetan += (r / L) * (UR - UL) * dt
#         plt.plot([Xs, Xn], [Ys, Yn], color="blue")
#     # Xn = round(Xn)
#     Thetan = 180 * (Thetan) / 3.14
#     return Xn, Yn, Thetan, D


# Function to check if the node is in an obstacle
# Defaultclearance is 5 but user defined
def check_in_obstacle(node, clr=5):
    # print(clr)
    x, y = node[0], node[1]
    # y = 300 - y
    # Inside circle
    dist = clr + radius
    # Bottom Left Circle
    if (x - 200) ** 2 + (y - 200) ** 2 <= (100 + dist) ** 2:
        # print("Coordinate inside circle obstacle")
        return True
    # Bottom Right Circle
    elif ((x - 200) ** 2) + (y - 800) ** 2 <= (100 + dist) ** 2:
        # print("Coordinate inside ellipse obstacle")
        return True
    # Left Rectangle
    elif 25 - dist <= x <= 175 + dist and 425 - dist <= y <= 575 + dist:
        # print("Coordinate inside C shaped obstacle")
        return True
    # Middle rectangle
    elif 375 - dist <= x <= 625 + dist and 425 - dist <= y <= 575 + dist:
        # print("Coordinate inside C shaped obstacle")
        return True
    # Right Rectangle
    elif 725 - dist <= x <= 875 + dist and 200 - dist <= y <= 400 + dist:
        # print("Coordinate inside C shaped obstacle")
        return True
    else:
        # print("Coordinates are good to go")
        return False


# Function to check if current node is at goal node
def check_solution(curr_node, goal_node):
    if curr_node[0] == goal_node[0] and curr_node[1] == goal_node[1]:
        return True
    else:
        return False


# Function for start and goal coordinates by user input
# Note that the origin of the workspace is bottom lef2
def get_coords():
    # Start positions
    start_x = 800
    start_y = 500
    # Default theta: 30
    # start_th = int(input("Enter starting theta position: "))
    start_th = 30  # Default
    start_node = (start_x, start_y, start_th)
    # Inputs for goal
    goal_x = 700
    goal_y = 700
    goal_th = 30

    goal_node = (goal_x, goal_y, goal_th)
    print("Starting at: ", start_node)
    print("Goal at: ", goal_x, goal_y)
    return start_x, start_y, start_th, goal_x, goal_y, goal_th, start_node, goal_node


# Function for action steps
def action_step(RPM_L, RPM_R):
    actions = [[0, RPM_L], [RPM_L, 0], [RPM_L, RPM_L], [RPM_L, RPM_R],
               [RPM_R, RPM_L], [RPM_R, RPM_R], [0, RPM_R], [RPM_L, 0],
               [0, -RPM_L], [-RPM_L, 0], [-RPM_L, -RPM_L], [0, -RPM_R],
               [-RPM_L, 0], [-RPM_R, -RPM_R], [-RPM_L, -RPM_R], [-RPM_R, -RPM_L]]

    return actions


# Function for determining next position
# Using differential drive constraints
def find_next(RPM_L, RPM_R, curr_node):
    # print("Current node", curr_node)
    t = 0
    r = 0.033*100
    L = 0.089*100
    dt = 0.1
    Xn = float(curr_node[1][0])
    Yn = float(curr_node[1][1])
    Thetan = 3.14 * curr_node[1][2] / 180*30

    UL = RPM_L
    UR = RPM_R
    while t < 1:
        t = t + dt
        Xn += 0.5 * r * (UL + UR) * math.cos(Thetan) * dt
        Yn += 0.5 * r * (UL + UR) * math.sin(Thetan) * dt
        Thetan += (r / L) * (UR - UL) * dt
        # D = D+ math.sqrt(math.pow((0.5*r * (UL + UR) * math.cos(Thetan) * dt), 2)+math.pow((0.5*r * (UL + UR) * math.sin(Thetan) * dt),2))
    Thetan = int((180 * Thetan / 3.14)%360)
    next_node = [Xn, Yn, Thetan]
    return next_node


# Function to calculate distance between points
def heuristic(point1, point2):
    h = math.sqrt((point2[0] - point1[0]) ** 2 + (point2[1] - point1[1]) ** 2)
    return h


# Function to convert x, y, and theta with the threshold
def discretize(x, y, theta, th_thresh, euc_thresh):
    x = (round(x / euc_thresh) * euc_thresh)
    y = (round(y / euc_thresh) * euc_thresh)
    theta = (round(theta / th_thresh) * th_thresh)
    return x, y, theta


# A* algorithm function
def a_star(start_node, goal_node, actions, RPM_L, RPM_R):
    print("======== A* ========")
    # Creates initial empty variables
    solvable = True
    path = {}
    child_node = []
    current_node = []
    parent_node = []
    visited = np.zeros(
        [int(1000 / euc), int(1000 / euc), int(360)])
    q = PriorityQueue()
    # Start and goal vectors
    start = (0, start_node, None)
    goal = (0, goal_node, None)
    start_node = discretize(
        start_node[0], start_node[1], start_node[2], theta_thresh, euc)
    goal_node = discretize(
        goal_node[0], goal_node[1], goal_node[2], theta_thresh, euc)
    param3 = 0
    q.put(start)  # adding the cost values in the queue
    if solvable:
        while q:
            curr_node = list(q.get())
            curr_node[0] = curr_node[0] - heuristic(curr_node[1], goal[1])

            if curr_node[2] is not None:
                node1 = str(curr_node[1][0])
                node2 = str(curr_node[1][1])
                node3 = str(curr_node[1][2])

                parent1 = str(curr_node[2][0])
                parent2 = str(curr_node[2][1])
                parent3 = str(curr_node[2][2])

                node_str = node1 + ',' + node2 + ',' + node3
                parent_str = parent1 + ',' + parent2 + ',' + parent3
                path[node_str] = parent_str

            else:
                node1 = str(curr_node[1][0])
                node2 = str(curr_node[1][1])
                node3 = str(curr_node[1][2])
                parent1 = str(curr_node[2])

                node_str = node1 + ',' + node2 + ',' + node3
                parent_str = parent1
                path[node_str] = parent_str

            # moves, step_size = action_step(curr_node, 1, theta_thresh)

            for action in actions:
                moves = find_next(action[0], action[1], curr_node)
                # print("Current node", curr_node[1][2])
                # print("Next node",  next_node)
                # print("Moves", moves)
                # print("Checking next node")
                # angle = moves[2] + curr_node[1][2]
                angle = moves[2]
                if angle <= 0:
                    angle = angle + 360
                elif angle >= 360:
                    angle = np.abs(angle - 360)
                elif angle == 360:
                    angle = 0
                # angle = angle*math.pi/180 #good angle w/o this but euc out of bounds error
                # update, after discretizing the angle its ok ? saving to shortest path is wrong
                print("Angle action", angle)
                node = (curr_node[1][0] + action[0],
                        curr_node[1][1] + action[1], angle)
                node = discretize(node[0], node[1], node[2], theta_thresh, euc)
                node_cost = curr_node[0] + \
                            moves[2] + heuristic(node, goal[1])
                node_parent = curr_node[1]
                print("Node after discretize: ", node)
                print("-------")
                if not check_in_obstacle(node):
                    # print("Checking if visited and obstacle")
                    if (ws_width - clr) > node[0] > 0 and (ws_height - clr) > node[1] > 0:
                        # try:
                        if visited[int(node[0] / euc)][int(node[1] / euc)][int(node[2] / theta_thresh)] == 0:
                            visited[int(node[0] / euc)][int(node[1] / euc)] = 1
                            parent_node1 = (node_parent[0], node_parent[1], node[2])  # og last is angle
                            parent_node.append(parent_node1)
                            # print(parent_node1)
                            # print(parent_node)
                            # print("=======\n")
                            # print("Angle", angle)
                            child_node = (node[0], node[1])
                            current_node.append(child_node)
                            # print(child_node)
                            next_node = (node_cost, node, node_parent)
                            q.put(next_node)
                        # except:
                        #     pass
                if check_solution(curr_node[1], goal_node):
                    print(">>At goal<<")
                    # Print operation time
                    print("--- %s seconds ---" % (time.time() - start_time))
                    backtracked = []
                    # Set parent points
                    p1 = str(curr_node[2][0])
                    p2 = str(curr_node[2][1])
                    p3 = str(curr_node[2][2])
                    parent = p1 + ',' + p2 + ',' + p3
                    # While parent is not none
                    print("Looping for parent")
                    while parent != "None":
                        # Set temp to get the parent
                        temp = path.get(parent)
                        # print(parent[-3:])
                        # Loop through to find backtrack nodes
                        if parent[-2] == ',':
                            param3 = float(parent[-1:])
                        if parent[-3] == ',':
                            param3 = float(parent[-2:])
                        if parent[-4] == ',':
                            param3 = float(parent[-3:])
                        if parent[1] == '.' and parent[5] == '.':
                            param1 = float(parent[0]) + float(parent[2]) / 10
                            param2 = float(parent[4]) + float(parent[6]) / 10
                        if parent[2] == '.' and parent[7] == '.':
                            param1 = float(
                                parent[0] + parent[1]) + float(parent[3]) / 10
                            param2 = float(
                                parent[5] + parent[6]) + float(parent[8]) / 10
                        if parent[1] == '.' and parent[6] == '.':
                            param1 = float(parent[0]) + float(parent[2]) / 10
                            param2 = float(
                                parent[4] + parent[5]) + float(parent[7]) / 10
                        if parent[2] == '.' and parent[6] == '.':
                            param1 = float(
                                parent[0] + parent[1]) + float(parent[3]) / 10
                            param2 = float(parent[5]) + float(parent[7]) / 10
                        if parent[3] == '.' and parent[9] == '.':
                            param1 = float(
                                parent[0] + parent[1] + parent[2]) + float(parent[4]) / 10
                            param2 = float(
                                parent[6] + parent[7] + parent[8]) + float(parent[10]) / 10
                        if parent[3] == '.' and parent[7] == '.':
                            param1 = float(
                                parent[0] + parent[1] + parent[2]) + float(parent[4]) / 10
                            param2 = float(parent[6]) + float(parent[8]) / 10
                        if parent[3] == '.' and parent[8] == '.':
                            param1 = float(
                                parent[0] + parent[1] + parent[2]) + float(parent[4]) / 10
                            param2 = float(
                                parent[6] + parent[7]) + float(parent[9]) / 10
                        if parent[1] == '.' and parent[7] == '.':
                            param1 = float(parent[0]) + float(parent[2]) / 10
                            param2 = float(
                                parent[4] + parent[5] + parent[6]) + float(parent[8]) / 10
                        if parent[2] == '.' and parent[8] == '.':
                            param1 = float(
                                parent[0] + parent[1]) + float(parent[3]) / 10
                            param2 = float(
                                parent[5] + parent[6] + parent[7]) + float(parent[9]) / 10
                        backtracked.append((param1, param2, param3))
                        parent = temp
                        # If the parameters are the start node, can terminate loop
                        if (param1, param2) == (start_node[0], start_node[1]):
                            break
                    backtracked.append((start_node[0], start_node[1], start_node[2]))
                    return backtracked, current_node, parent_node, visited


# # Function for visualizing the path and search
# def visual(path, img, current_node, parent, out):
#     imgcopy = img.copy()
#     # Set search color to blue
#     for i in range(len(current_node) - 1):
#         imgcopy[1000 - int(current_node[i][1]),
#                 int(current_node[i][0]) - 1] = [255, 0, 0]
#         # cv2.circle(imgcopy, (299 - int(current_node[i][1]), int(current_node[i][0]) - 1), 3, (255, 255, 0))
#         # out.write(imgcopy)
#     # Draws the optimal path
#     for j in range(len(path) - 1):
#         imgcopy = cv2.line(imgcopy, (int(path[j][0]) - 1, 1000 - int(path[j][1])),
#                            (int(path[j + 1][0]) - 1, 1000 - int(path[j + 1][1])), (255, 255, 255), 2)
#         # out.write(imgcopy)
#     # Saves to video and returns the frame
#     return imgcopy


# def move_robot(path, actions):
#     vel_msg = Twist()
#     vel_msg.linear.z = 0
#     vel_msg.angular.x = 0
#     vel_msg.angular.y = 0
#     vel_msg.angular.z = 0
#     for action in actions:
#         vel_msg = Twist()
#         wheel_l = action[0]
#         wheel_r = action[1]
#         # Get linear velocity
#         vel_lin = (wheel_r/2)*(wheel_l + wheel_r)
#         # Get angular velocity
#         vel_ang = ((wheel_r - wheel_l)*(wheel_r)/(2*radius))
#         vel_msg.linear.x = vel_lin
#         vel_msg.angular.z = -1*vel_ang
#         vel_pub.publish(vel_msg)
#         vel_msg = Twist()


def go_straight(distance_to_drive, linear_velocity):
    # get distance and linear velocity from command line
    global velocity_msg
    # update linear.x from the command line
    velocity_msg.angular.z = 0.0
    velocity_msg.linear.x = linear_velocity
    # get the current time (s)
    t_0 = rospy.Time.now().to_sec()
    # keep track of the distance
    distance_moved = 0.0

    # while the amount of distance has not been reached
    while distance_moved <= distance_to_drive:
        # rospy.loginfo("TurtleBot is moving")
        pub.publish(velocity_msg)
        rate.sleep()
        # time in sec in the loop
        t_1 = rospy.Time.now().to_sec()
        distance_moved = (t_1 - t_0) * abs(linear_velocity)
        # rospy.loginfo("distance moved: {d}".format(d=distance_moved))

    # rospy.logwarn("Distance reached")
    # finally, stop the robot when the distance is moved
    velocity_msg.linear.x = 0.0
    velocity_msg.angular.z = 0.0
    pub.publish(velocity_msg)


def rotate(angle, angular_velocity):
    """Make the robot rotate in place

    The angular velocity is modified before publishing the message on the topic /cmd_vel.
    """
    print("Rotating")
    # angular_velocity = math.radians(angular_velocity)
    velocity_msg.linear.x = 0.0
    velocity_msg.angular.z = angular_velocity
    t0 = rospy.Time.now().to_sec()
    while True:
        # rospy.loginfo("TurtleBot is rotating")
        pub.publish(velocity_msg)
        rate.sleep()
        t1 = rospy.Time.now().to_sec()
        # rospy.loginfo("t0: {t}".format(t=t0))
        # rospy.loginfo("t1: {t}".format(t=t1))
        current_angle_degree = (t1 - t0) * angular_velocity
        # current_angle_degree = current_angle_degree*180/math.pi
        # rospy.loginfo("current angle: {a}".format(a=current_angle_degree))
        # rospy.loginfo("angle to reach: {a}".format(a=angle))
        if abs(current_angle_degree) >= math.radians(abs(angle)):
            # rospy.loginfo("reached")
            break
    # finally, stop the robot when the distance is moved
    velocity_msg.angular.z = 0
    pub.publish(velocity_msg)


def get_odom_data():
    """Get the current pose of the robot from the /odom topic

    Return
    ----------
    The position (x, y, z) and the yaw of the robot.
    """
    try:
        (trans, rot) = tf_listener.lookupTransform(
            parent_frame, child_frame, rospy.Time(0))
        # rotation is a list [r, p, y]
        rotation = euler_from_quaternion(rot)
    except (tf.Exception, tf.ConnectivityException, tf.LookupException):
        rospy.loginfo("TF Exception")
        return
    # return the position (x, y, z) and the yaw
    return Point(*trans), rotation[2]


def go_to_goal(current_node, next_node):
    (pos, rot) = get_odom_data()
    print(rot)
    x_start = current_node[0]
    y_start = current_node[1]
    rotation = current_node[2]
    goal_x = next_node[0]
    goal_y = next_node[1]
    goal_theta = next_node[2]
    distance_to_drive_x = abs((goal_x - x_start) / 100)
    print("x :", distance_to_drive_x)
    distance_to_drive_y = abs((goal_y - y_start) / 100)
    print("y :", distance_to_drive_y)
    # angle_to_goal = goal_theta - rotation
    angle_to_goal = 0
    if x_start == goal_x and y_start < goal_y and (1.0 < rot < 2.5):
        angle_to_goal = 0
        go_straight(distance_to_drive_y, 0.2)
    elif x_start == goal_x and y_start == goal_y:
        pass
    elif x_start == goal_x and y_start > goal_y and (-1.8 < rot < -1.4):
        angle_to_goal = 0
        go_straight(distance_to_drive_y, 0.2)
    elif x_start == goal_x and y_start < goal_y and (-0.1 < rot < 1.4):
        angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
        angle_to_goal = angle_to_goal*180/math.pi
        rotate(angle_to_goal, 0.2)
        go_straight(distance_to_drive_y, 0.2)
    elif x_start == goal_x and y_start > goal_y and (-0.45 < rot < 1.4):
        angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
        angle_to_goal = angle_to_goal*180/math.pi
        print("hello")
        rotate(angle_to_goal, -0.2)
        go_straight(distance_to_drive_y, 0.2)
    elif x_start == goal_x and y_start < goal_y and (rot > 2.5 or rot < -2.5):
        angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
        angle_to_goal = angle_to_goal*180/math.pi
        print("world")
        rotate(angle_to_goal, -0.2)
        go_straight(distance_to_drive_y, 0.2)
    elif x_start == goal_x and y_start > goal_y and (rot > 2.5 or rot < -2.5):
        angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
        angle_to_goal = angle_to_goal*180/math.pi
        rotate(angle_to_goal, 0.2)
        go_straight(distance_to_drive_y, 0.2)
    elif x_start < goal_x and y_start == goal_y and (-0.1 < rot < 0.1):
        angle_to_goal = 0
        go_straight(distance_to_drive_x, 0.2)
    elif x_start > goal_x and y_start == goal_y and (1.0 < rot < 2.5):
        # angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
        # angle_to_goal = angle_to_goal*180/math.pi
        angle_to_goal = 90
        rotate(angle_to_goal, 0.2)
        go_straight(distance_to_drive_x, 0.2)
    elif x_start < goal_x and y_start == goal_y and (1.0 < rot < 2.5):
        # angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
        # angle_to_goal = angle_to_goal*180/math.pi
        angle_to_goal = 90
        print("nice")
        rotate(angle_to_goal, -0.2)
        go_straight(distance_to_drive_x, 0.2)
    elif x_start < goal_x and y_start == goal_y and (-1.8 < rot < -1.4):
        # angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
        # angle_to_goal = angle_to_goal*180/math.pi
        angle_to_goal = 90
        rotate(angle_to_goal, 0.2)
        go_straight(distance_to_drive_x, 0.2)
    elif x_start > goal_x and y_start == goal_y and (-1.8 < rot < -1.0):
        # angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
        # angle_to_goal = angle_to_goal*180/math.pi
        angle_to_goal = 90
        print("to")
        rotate(angle_to_goal, -0.2)
        go_straight(distance_to_drive_x, 0.2)
    elif x_start < goal_x and y_start == goal_y and (-2.0 < rot < -1.0):
        # angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
        # angle_to_goal = angle_to_goal*180/math.pi
        angle_to_goal = 90
        rotate(angle_to_goal, 0.2)
        go_straight(distance_to_drive_x, 0.2)
    elif x_start < goal_x and y_start < goal_y and (-0.1 < rot < 0.1):
        angle_to_goal = 45
        rotate(angle_to_goal, 0.2)
        go_straight(distance_to_drive_x, 0.2)
    elif x_start < goal_x and y_start < goal_y and (1.4 < rot < 1.8):
        angle_to_goal = 45
        print("meet")
        rotate(angle_to_goal, -0.2)
        distance_to_drive = np.sqrt(distance_to_drive_y ** 2 + distance_to_drive_x **2)
        go_straight(distance_to_drive, 0.2)
    elif x_start < goal_x and y_start < goal_y and (0.35 < rot < 1.3):
        distance_to_drive = np.sqrt(distance_to_drive_y ** 2 + distance_to_drive_x **2)
        go_straight(distance_to_drive, 0.2)
    elif x_start < goal_x and y_start == goal_y and (0.35 < rot < 1.3):
        angle_to_goal = 45
        rotate(angle_to_goal, -0.2)
        go_straight(distance_to_drive_x, 0.2)
        time.sleep(1)

    # else:
    #     angle_to_goal = math.atan2(goal_y - y_start, goal_x - x_start)
    #     angle_to_goal = angle_to_goal*180/math.pi  # Added ata2 and degree conversion
    # if angle_to_goal < -math.pi / 4 or angle_to_goal > math.pi / 4:
    #     if 0 > goal_y > y_start:
    #         angle_to_goal = -2 * math.pi + angle_to_goal
    #     elif 0 <= goal_x < x_start:
    #         angle_to_goal = 2 * math.pi + angle_to_goal
    # t_0 = rospy.Time.now().to_sec()
    # distance_moved_x = 0.0
    # distance_moved_y = 0.0

    print("Go to goal angle", angle_to_goal)
    # if angle_to_goal <= 0:
    #     rotate(angle_to_goal, 0.2)
    # else:
    #     rotate(angle_to_goal, -0.2)
    # if angle_to_goal == 0 and abs(distance_to_drive_x) > 0:
    #     go_straight(distance_to_drive_x, 0.2)
    #     # velocity_msg.angular.z = 0.0
    #     # velocity_msg.linear.x = 0.05
    #     # pub.publish(velocity_msg)
    #     # rate.sleep()
    #     # t_1 = rospy.Time.now().to_sec()
    #     # distance_moved_x = (t_1 - t_0) * abs(velocity_msg.linear.x)
    # elif angle_to_goal == 0 and abs(distance_to_drive_y) > 0:
    #     go_straight(distance_to_drive_y, 0.2)
    # else:

    #
    # velocity_msg.angular.z = k_v_gain * angle_to_goal-rotation
    # velocity_msg.linear.x = 0.15
    # # set the z angular velocity for positive and negative rotations
    # if velocity_msg.angular.z > 0:
    #     velocity_msg.angular.z = min(velocity_msg.angular.z, 0.15)
    # else:
    #     velocity_msg.angular.z = max(velocity_msg.angular.z, -0.15)
    #
    # last_rotation = rotation
    # pub.publish(velocity_msg)
    # rate.sleep()

    # velocity_msg.linear.x = 0.0
    # velocity_msg.angular.z = 0.0
    # pub.publish(velocity_msg)


# def move_robot(pub, dvx, dvy, dw):
#     r = rospy.Rate(100)
#     vel = Twist()
#     vel_x = (np.sqrt(dvx * dvx + dvy * dvy)) / 1000
#     endTime = rospy.Time.now() + rospy.Duration(1.5)
#     while rospy.Time.now() < endTime:
#         vel.linear.x = vel_x
#         vel.angular.z = dw
#         pub.publish(vel)
#         r.sleep()
#     vel.linear.x = 0
#     vel.angular.z = 0
#     pub.publish(vel)


# Main function
def main():
    # Define global variables and user inputs
    global clr  # clearance
    # clr = int(input("Define the clearance distance between objects:"))
    clr = 5

    # Ask user for start and goal position
    start_x, start_y, start_th, goal_x, goal_y, goal_th, start_node, goal_node = get_coords()
    RPM_L = 5
    RPM_R = 5
    # RPM_L, RPM_R = [int(x) for x in input(
    #     "Enter RPM for left and right wheels: ").split()]
    actions = action_step(RPM_L, RPM_R)
    # Call A star function and return the shortest path
    shortest_path, current_node, parent_node, visited = a_star(
        start_node, goal_node, actions, RPM_L, RPM_R)
    # print(shortest_path)
    fig, ax = plt.subplots()
    for i in range(len(shortest_path) - 1):
        plt.plot([shortest_path[i][0], shortest_path[i + 1][0]], [shortest_path[i][1], shortest_path[i + 1][1]],
                 color='red')
    plt.grid()
    ax.set_aspect('equal')
    plt.xlim(0, 1000)
    plt.ylim(0, 1000)
    plt.title('Map', fontsize=10)
    shortest_path.reverse()
    print(shortest_path)
    plt.show()
    for i in range(len(shortest_path) - 1):
        if i == 0:
            continue
        go_to_goal(shortest_path[i], shortest_path[i + 1])
        # time.sleep(1)
    rospy.logwarn("Reached Goal!!")
    vel = Twist()
    vel.linear.x = 0.0
    vel.angular.z = 0.0
    pub.publish(vel)
    plt.close()
    # move_robot(shortest_path, actions)
    # # Creates shortest_path text file to store the optimal path
    # file = open("shortest_path.txt", "w+")
    # for i in shortest_path:
    #     file.write(str(i) + "\n")
    #     file.write("-------------" + "\n")
    # file.close()
    # # Creates backtrack_path text file to store the backtrack path taken
    # file = open("backtrack_path.txt", "w+")
    # for i in current_node:
    #     file.write(str(i) + "\n")
    #     file.write("-------------" + "\n")
    # file.close()
    # End of main


if __name__ == '__main__':
    # # parent frame for the listener
    # parent_frame = 'odom'
    # # child frame for the listener
    # child_frame = 'base_footprint'
    # gains for the proportional controllers. These values can be tuned.
    k_h_gain = 1
    k_v_gain = 1
    main()